#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "openlog.h"
#include <string.h>

void initOpenLog(void) {
    // Enable clocks
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE); // USART3 is on APB1
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC, ENABLE);   // GPIOC clock for PC10 and PC11

    // Configure PC10 as alternate function (TX)
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;      // TX
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOC, &GPIO_InitStruct);

    // Configure PC11 as alternate function (RX)
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_11;
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz;
    GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_UP;
    GPIO_Init(GPIOC, &GPIO_InitStruct);

    GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_7); // AF7 = USART3
    GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_7); // AF7 = USART3

    // Configure USART3
    USART_InitTypeDef USART_InitStruct;
    USART_StructInit(&USART_InitStruct);
    USART_InitStruct.USART_BaudRate = 9600;               // Match OpenLog default
    USART_InitStruct.USART_WordLength = USART_WordLength_8b;
    USART_InitStruct.USART_StopBits = USART_StopBits_1;
    USART_InitStruct.USART_Parity = USART_Parity_No;
    USART_InitStruct.USART_Mode = USART_Mode_Tx | USART_Mode_Rx;
    USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_Init(USART3, &USART_InitStruct);

    // Enable USART3
    USART_Cmd(USART3, ENABLE);

    // Small delay to let OpenLog settle
    for (volatile int i = 0; i < 2000000; i++);
}

void USART3_SendString(char *str) {
	// Send string one letter at a time
    while(*str) {
        while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
        USART_SendData(USART3, *str++);
    }
}

void openlog_command_mode(void){
    // Enter command mode
    for (int i=0; i<3; i++) {
        while (USART_GetFlagStatus(USART3, USART_FLAG_TXE) == RESET);
        USART_SendData(USART3, 26); // ASCII 26 = Ctrl+Z 3 times
    }
    for (volatile int i=0;i<2000000;i++);
}

void openlog_new_file(const char *filename) {
    char cmd[64]; // Buffer to save the command and name of the new file

    // Save in buffer as "new <filename>\r"
    strcpy(cmd, "new ");
    strcat(cmd, filename);
    strcat(cmd, "\r\n");

    // Send command to OpenLog
    USART3_SendString(cmd);

    for (volatile int i = 0; i < 2000000; i++);
}

void openlog_append_file(char *filename){
	char cmd[64]; // Buffer to save the command and name of the new file

    // Save in buffer as "append <filename>\r"
    strcpy(cmd, "append ");
    strcat(cmd, filename);
    strcat(cmd, "\r");

    // Send to openlog
    USART3_SendString(cmd);

    for (volatile int i=0;i<2000000;i++);
}
