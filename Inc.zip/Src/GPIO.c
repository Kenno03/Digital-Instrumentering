/*
 * GPIO.c
 *
 *  Created on: 2. sep. 2025
 *      Author: muusn
 */
#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course


void initJoystick(){
	//PC0 (right), PA4 (up), PB5 (center), PC1 (left), and PB0 (down)

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA,ENABLE); // Enable clock for GPIO Port A
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB,ENABLE); // Enable clock for GPIO Port B
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC,ENABLE); // Enable clock for GPIO Port C
	GPIO_InitTypeDef GPIO_InitStructAll; // Define typedef struct for setting pin

	// Sets PC0 to input
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_IN; // Set as input
	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_DOWN; // Set as pull down
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_0; // Set so the configuration is on pin 0
	GPIO_Init(GPIOC, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	// Sets PA4 to input
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_IN; // Set as input
	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_DOWN; // Set as pull down
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_4; // Set so the configuration is on pin 4
	GPIO_Init(GPIOA, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	// Sets PB5 to input
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_IN; // Set as input
	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_DOWN; // Set as pull down
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_5; // Set so the configuration is on pin 5
	GPIO_Init(GPIOB, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	// Sets PC1 to input
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_IN; // Set as input
	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_DOWN; // Set as pull down
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_1; // Set so the configuration is on pin 1
	GPIO_Init(GPIOC, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	// Sets PB0 to input
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_IN; // Set as input
	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_DOWN; // Set as pull down
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_0; // Set so the configuration is on pin 0
	GPIO_Init(GPIOB, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

}

int8_t readJoystick(){
	//PC0 (right), PA4 (up), PB5 (center), PC1 (left), and PB0 (down)
	int8_t joyState = 0;


	if (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_4))joyState = 0x01;// Up
	else if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0))joyState = 0x01 << 1; // Down
	else if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_1))joyState = 0x01 << 2; // Left
	else if (GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_0))joyState = 0x01 << 3; // Right
	else if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5))joyState = 0x01 << 4; // Center

	return joyState;
}

void initLed(){
	// Red is connected to PB4, green to PC7, and blue to PA9

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA,ENABLE); // Enable clock for GPIO Port A
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB,ENABLE); // Enable clock for GPIO Port B
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC,ENABLE); // Enable clock for GPIO Port C
	GPIO_InitTypeDef GPIO_InitStructAll; // Define typedef struct for setting pin


	// Sets PB4 to output
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_OUT; // Set as output
	GPIO_InitStructAll.GPIO_OType = GPIO_OType_PP; // Set as Push-Pull
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_4; // Set so the configuration is on pin 9
	GPIO_InitStructAll.GPIO_Speed = GPIO_Speed_2MHz; // Set speed to 2 MHz
	GPIO_Init(GPIOB, &GPIO_InitStructAll); // Setup of GPIO with the settings chose

	// Sets PC7 to output
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_OUT; // Set as output
	GPIO_InitStructAll.GPIO_OType = GPIO_OType_PP; // Set as Push-Pull
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_7; // Set so the configuration is on pin 9
	GPIO_InitStructAll.GPIO_Speed = GPIO_Speed_2MHz; // Set speed to 2 MHz
	GPIO_Init(GPIOC, &GPIO_InitStructAll); // Setup of GPIO with the settings chose

	// Sets PA9 to output
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_OUT; // Set as output
	GPIO_InitStructAll.GPIO_OType = GPIO_OType_PP; // Set as Push-Pull
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_9; // Set so the configuration is on pin 9
	GPIO_InitStructAll.GPIO_Speed = GPIO_Speed_2MHz; // Set speed to 2 MHz
	GPIO_Init(GPIOA, &GPIO_InitStructAll); // Setup of GPIO with the settings chose

	GPIO_WriteBit (GPIOB, GPIO_Pin_4, 1);
	GPIO_WriteBit (GPIOC, GPIO_Pin_7, 1);
	GPIO_WriteBit (GPIOA, GPIO_Pin_9, 1);

}


void setLed(int8_t color){

	if (color == 1){
		GPIO_WriteBit (GPIOB, GPIO_Pin_4, 1);
		GPIO_WriteBit (GPIOC, GPIO_Pin_7, 0);
		GPIO_WriteBit (GPIOA, GPIO_Pin_9, 0);
	}
	else if (color == 2){
		GPIO_WriteBit (GPIOB, GPIO_Pin_4, 0);
		GPIO_WriteBit (GPIOC, GPIO_Pin_7, 1);
		GPIO_WriteBit (GPIOA, GPIO_Pin_9, 0);
	}
	else if (color == 4){
		GPIO_WriteBit (GPIOB, GPIO_Pin_4, 0);
		GPIO_WriteBit (GPIOC, GPIO_Pin_7, 0);
		GPIO_WriteBit (GPIOA, GPIO_Pin_9, 1);
	}
	else if (color == 8){
		GPIO_WriteBit (GPIOB, GPIO_Pin_4, 1);
		GPIO_WriteBit (GPIOC, GPIO_Pin_7, 1);
		GPIO_WriteBit (GPIOA, GPIO_Pin_9, 0);
	}
	else if (color == 16){
		GPIO_WriteBit (GPIOB, GPIO_Pin_4, 0);
		GPIO_WriteBit (GPIOC, GPIO_Pin_7, 1);
		GPIO_WriteBit (GPIOA, GPIO_Pin_9, 1);
	}

}







