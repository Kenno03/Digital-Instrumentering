#ifndef GPIO_H_
#define GPIO_H_

void initJoystick();
int8_t readJoystick();
void initLed();
void setLed();

#endif /* GPIO_H_ */
