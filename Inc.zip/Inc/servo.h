#ifndef SERVO_H_
#define SERVO_H_

#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "homing.h"

void init_servo_PA12(void);
void update_servo(uint8_t degrees, uint32_t *lastPulse);
void find_light(uint16_t *tilt_degrees, uint16_t *pan_degrees,SunPosition pos);

#endif /* SERVO_H_ */
