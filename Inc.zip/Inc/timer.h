#ifndef CONTROLS_H_
#define CONTROLS_H_

// --- Timer functions ---
void initTimer(void);

typedef struct {
    uint8_t hs;
    uint8_t s;
    uint8_t m;
} time;

extern volatile time sw;  // declare, not define

#endif /* CONTROLS_H_ */
