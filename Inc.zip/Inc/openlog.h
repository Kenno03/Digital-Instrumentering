#ifndef OPENLOG_H_
#define OPENLOG_H_
#include "stm32f30x_conf.h" // STM32 config

void initOpenLog();
void USART3_SendString(char *str);
void openlog_command_mode(void);
void openlog_new_file(const char *filename);
void openlog_append_file(char *filename);

#endif /* OPENLOG_H_ */
