#ifndef PWM_H_
#define PWM_H_

void timer16_clock_init(void);
void timer16_pwm_init(uint16_t pulse);
void GPIO_set_AF1_PA6(void);

void timer2_clock_init(void);
void timer2_pwm_init(uint16_t pulse);
void GPIO_set_AF1_PB11(void);

#endif /* PWM_H_ */
