#ifndef INTERRUPT_H_
#define INTERRUPT_H_

void initInterrupt();

#endif /* INTERRUPT_H_ */
