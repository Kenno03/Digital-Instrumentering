#ifndef ADC_H_
#define ADC_H_

#define VREFINT_CAL *((uint16_t*) ((uint32_t) 0x1FFFF7BA))   //calibrated at 3.3V@ 30C

void ADC_setup_PA();
uint16_t ADC_measure_PA(uint8_t ch);
float ADC_absolute_voltage(uint16_t ADC_data);
float ADC_measure_vdda(void);
float ADC_absolute_voltage_calibrated(uint16_t ADC_data, float VDDA);


#endif /* ADC_H_ */
