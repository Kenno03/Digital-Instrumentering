#include <shift595.h>
#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "stepper_motor_angle.h"
#include <stdint.h>
#include "servo.h"
#include "photoresistors.h"
#include "homing.h"
#include "timer.h"

int main(void) {


	/*
	 * Homing setup
	 */
	float latitude = 55.7861;
	float longitude = 12.5234;
	datetime utc = {2025, 11, 4, 0, 0, 0};
	double JD = utc_to_julian(utc); // 2025-11-04 14:00:000 UTC
	SunPosition pos = sun_position(latitude, longitude, JD);
    uint32_t last_print = 0; // keep track of last print in hundredths of seconds



    uart_init(9600);

    // Initialize 74HC595 GPIO pins
    gpio_init_74hc595();
    initTimer();

    // Small startup delay
    delay_ms(200);

    float azimuth_tracker = 0;

    while (1) {
        uint32_t total_hs = sw.m*60*100 + sw.s*100 + sw.hs;

         // Check if 5 seconds (500 hundredths) have passed
         if (total_hs - last_print >= 500) {
             last_print = total_hs;
             // printf("%02d:%02d:%02d\n", sw.m, sw.s, sw.hs);

             utc.h += 3;

             if (utc.h >= 24) {
                 utc.h -= 24;   // subtract 24 hours to wrap around
                 utc.D += 1;    // increment the day
             }

             printf("UTC time: %d-%.2d-%.2d %.2d:%.2d:%.2d\n", utc.Y, utc.M, utc.D, utc.h, utc.m, utc.s);

             JD += 0.125;

            printf("Julian date: %.4f\n", JD);

 			SunPosition pos = sun_position(latitude, longitude, JD);
 			printf("Azimuth %.2f, Turn to %.2f \n", pos.azimuth,(azimuth_tracker + pos.azimuth));

 			// Constrains the azimuth angle
 			if(azimuth_tracker + pos.azimuth < 360){
 	    	moveStepperToAngle(pos.azimuth);
 			azimuth_tracker += pos.azimuth;
 			}
 			else if(azimuth_tracker + pos.azimuth > 360){
 				moveStepperToAngle(pos.azimuth - 360);
 	 			azimuth_tracker -= pos.azimuth;
 			}

 	    	delay_ms(100);
 			}



         }
    return 0;
}
