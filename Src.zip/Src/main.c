#include <shift595.h>
#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "stepper_motor_angle.h"
#include <stdint.h>
#include "servo.h"
#include "photoresistors.h"
#include "homing.h"
#include "timer.h"
#include "lcd.h"

void lcd_write_string(uint8_t * str, uint8_t * lcdBuff, uint8_t x, uint8_t y
);





int main(void) {

	ADC_setup_5_photo();
	init_servo_PA12();

	/*
	 * Homing setup
	 */
	float latitude = 55.7861;
	float longitude = 12.5234;
	datetime utc = {2025, 11, 4, 12, 0, 0};
	double JD = utc_to_julian(utc); // 2025-11-04 14:00:000 UTC
	SunPosition pos = sun_position(latitude, longitude, JD);
    uint32_t last_print = 0; // keep track of last print in hundredths of seconds

    uint16_t tilt_degrees = 90;
    uint16_t pan_degrees = 180;
    uint32_t last_pulse = 0;


    uart_init(9600);

    // Initialize 74HC595 GPIO pins
    gpio_init_74hc595();
    initTimer();

    // Small startup delay
    delay_ms(200);

    if (pos.elevation > 0){
        update_servo(pos.elevation, &last_pulse);
    }
    else{
    	update_servo(0, &last_pulse);
    }




    init_spi_lcd();
    uint8_t fbuffer [512];
    //Clears the lcd

    memset(fbuffer,0x00,512);
    lcd_push_buffer(fbuffer);

    char str[32];
    uint8_t a = 42;

    // Format text into str
    sprintf(str, "a = %d Get the joke?", a);
    lcd_write_string((uint8_t*)str, fbuffer, 0, 0);
    lcd_push_buffer(fbuffer);


    while (1) {
        find_light(&tilt_degrees, &pan_degrees, pos);
        update_servo(tilt_degrees, &last_pulse);

    	uint32_t total_hs = sw.m*60*100 + sw.s*100 + sw.hs;

         // Check if 5 seconds (500 hundredths) have passed
         if (total_hs - last_print >= 500) {
             last_print = total_hs;
             // printf("%02d:%02d:%02d\n", sw.m, sw.s, sw.hs);

             utc.s += 5;

             if (utc.h >= 24) {
                 utc.h -= 24;   // subtract 24 hours to wrap around
                 utc.D += 1;    // increment the day
             }

             printf("UTC time: %d-%.2d-%.2d %.2d:%.2d:%.2d\n", utc.Y, utc.M, utc.D, utc.h, utc.m, utc.s);

             JD += 0; // 0.125;

            printf("Julian date: %.4f\n", JD);

 			SunPosition pos = sun_position(latitude, longitude, JD);

 			printf("Azimuth:%f\n", pos.azimuth);
 			printf("Elevation:%f\n", pos.elevation);

 			printf("pan_degrees: %d\n", pan_degrees);

         }
    }
    return 0;
}
