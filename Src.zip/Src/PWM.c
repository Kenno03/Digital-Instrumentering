#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course

void timer16_clock_init(void){
	// Initialize timer 16 with settings for a PWM signal
	// Enable timer 16 clock
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM16, ENABLE);

	// Set the clock in upcounting mode and to trigger an interrupt with 50Hz
	TIM_TimeBaseInitTypeDef TIM_InitStructure;
	TIM_TimeBaseStructInit(&TIM_InitStructure);
	TIM_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_InitStructure.TIM_Prescaler = 639; // 64 MHz / (639+1) = 100 kHz tick
	TIM_InitStructure.TIM_Period = 1999; // 2000 ticks * 10 µs = 20 ms
	TIM_TimeBaseInit(TIM16,&TIM_InitStructure); // Run the initialization of the timer with the given settings
}

void timer16_pwm_init(uint16_t pulse){
	// Initialize the PWM settings of the timer, by initializing the output compare for the given channel

	// Enable Output compare in PMW mode
	TIM_OCInitTypeDef TIM_OCInitStruct;
	TIM_OCStructInit(&TIM_OCInitStruct);
	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OC1Init(TIM16, &TIM_OCInitStruct);

	TIM_OC1PreloadConfig(TIM16, TIM_OCPreload_Enable);

	// Enable the PWM output
	TIM_CtrlPWMOutputs(TIM16, ENABLE);
	TIM_Cmd(TIM16,ENABLE);

	// Set the initial TIM16 pulse, given as an input to the initialization function
	TIM_SetCompare1(TIM16, pulse);
}


void GPIO_set_AF1_PA6(void){
	// Initialize the PA6 GPIO pin to output a PWM signal, by using the alternate function mode

	// Enable the GPIO port clock
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA,ENABLE); // Enable clock for GPIO Port A

	// Initialize the GPIO pin
	GPIO_InitTypeDef GPIO_InitStructAll; // Define typedef struct for setting pin
	GPIO_StructInit(&GPIO_InitStructAll);
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_AF; // Alternate function
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_6; // Pin PA6
	GPIO_InitStructAll.GPIO_Speed = GPIO_Speed_50MHz; // Set speed of the pin to 50MHz
	GPIO_Init(GPIOA, &GPIO_InitStructAll);

	// Select the pin for alternate function 1:
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource6,GPIO_AF_1); // TIM16_CH1
}


// Setup timer 2 for a second servo motor:
void timer2_clock_init(void) {
	// Initialize timer 2 with settings for a PWM signal

	// Enable timer 2 clock
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    // Set the clock in upcounting mode and to trigger an interrupt with 50Hz
    TIM_TimeBaseInitTypeDef TIM_InitStructure;
    TIM_TimeBaseStructInit(&TIM_InitStructure);
    TIM_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_InitStructure.TIM_CounterMode   = TIM_CounterMode_Up;
	TIM_InitStructure.TIM_Prescaler = 639; // 64 MHz / (639+1) = 100 kHz tick
	TIM_InitStructure.TIM_Period = 1999; // 2000 ticks * 10 µs = 20 ms
    TIM_TimeBaseInit(TIM2, &TIM_InitStructure);
}

void timer2_pwm_init(uint16_t pulse) {
	// Initialize the PWM settings of the timer, by initializing the output compare for the given channel

	// Enable Output compare in PMW mode
    TIM_OCInitTypeDef TIM_OCInitStruct;
    TIM_OCStructInit(&TIM_OCInitStruct);
    TIM_OCInitStruct.TIM_OCMode        = TIM_OCMode_PWM1;
    TIM_OCInitStruct.TIM_OutputState   = TIM_OutputState_Enable;
    TIM_OC4Init(TIM2, &TIM_OCInitStruct);   // Channel 4

    // Enable the PWM output
    TIM_OC4PreloadConfig(TIM2, TIM_OCPreload_Enable);
    TIM_Cmd(TIM2, ENABLE);

    // Set the initial TIM16 pulse, given as an input to the initialization function
    TIM_SetCompare4(TIM2, pulse);  // set initial pulse
}


void GPIO_set_AF1_PB11(void) {
	// Initialize the PB11 GPIO pin to output a PWM signal, by using the alternate function mode

	// Enable the GPIO port clock
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOB, ENABLE);

    // Initialize the GPIO pin
    GPIO_InitTypeDef GPIO_InitStruct;
    GPIO_StructInit(&GPIO_InitStruct);
    GPIO_InitStruct.GPIO_Mode  = GPIO_Mode_AF; // Alternate function
    GPIO_InitStruct.GPIO_Pin   = GPIO_Pin_11; // Pin PB11
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz; // Speed 50MHz
    GPIO_Init(GPIOB, &GPIO_InitStruct);

    // Select the pin for alternate function 1:
    GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_1);  // TIM2_CH4
}
