#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "ADC.h"

void ADC_setup_PA(){
	// This function configures the ADC clock, the GPIO pins connected to the mbed potentiometers, and sets the desired ADC settings

	// Enable clocks
	RCC_ADCCLKConfig(RCC_ADC12PLLCLK_Div8);

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_ADC12,ENABLE);

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOA, ENABLE);


	// Initialize GPIO pins as analog inputs
	GPIO_InitTypeDef GPIO_InitStructAll; // Define typedef struct for setting pin
	// Sets PA0 to input
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_AN; // Set as input
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_0; // Set so the configuration is on pin 0
	GPIO_Init(GPIOA, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	// Sets PA1 to input
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct
	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_AN; // Set as input
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_1; // Set so the configuration is on pin 0
	GPIO_Init(GPIOA, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen


	// Configure the ADC with the desired settings
	ADC_InitTypeDef ADC_InitStructAll;

	ADC_StructInit(&ADC_InitStructAll);
	ADC_InitStructAll.ADC_ContinuousConvMode = DISABLE;
	ADC_InitStructAll.ADC_Resolution = ADC_Resolution_12b;
	ADC_InitStructAll.ADC_DataAlign = ADC_DataAlign_Right;
	ADC_InitStructAll.ADC_ExternalTrigConvEvent = ADC_ExternalTrigConvEvent_0;
	ADC_InitStructAll.ADC_ExternalTrigEventEdge = ADC_ExternalTrigEventEdge_None;
	ADC_InitStructAll.ADC_NbrOfRegChannel = 1;
	ADC_Init(ADC1, &ADC_InitStructAll);

	// Enable ADC 1
	ADC_Cmd(ADC1, ENABLE);

	while(!ADC_GetFlagStatus(ADC1,ADC_FLAG_RDY)){}

	// set internal reference voltage source
	ADC_VoltageRegulatorCmd(ADC1,ENABLE);
	//Wait for at least 10uS before continuing...
	for(uint32_t i = 0; i<10000;i++);

	// Run the internal calibration
	ADC_Cmd(ADC1,DISABLE);
	while(ADC_GetDisableCmdStatus(ADC1)){} // wait for disable of ADC
	ADC_SelectCalibrationMode(ADC1,ADC_CalibrationMode_Single);
	ADC_StartCalibration(ADC1);
	while(ADC_GetCalibrationStatus(ADC1)){}
	for(uint32_t i = 0; i<100;i++);

	// Enable the ADC and setup reference voltage
	ADC_Cmd(ADC1,ENABLE);
	while(!ADC_GetFlagStatus(ADC1,ADC_FLAG_RDY)){}

	ADC_VrefintCmd(ADC1,ENABLE); // setup reference voltage to channel 18
	for(uint32_t i = 0; i<10000;i++); // Wait

}


uint16_t ADC_measure_PA(uint8_t ch){
	// This function measures the voltage of a given channel (1 or 2) and outputs a 16-bit digital value of the ADC reading

	uint16_t x = 0;

	// Choose channel to read from
	if (ch == 1) {
	    ADC_RegularChannelConfig(ADC1, ADC_Channel_1, 1, ADC_SampleTime_1Cycles5);
	} else if (ch == 2) {
	    ADC_RegularChannelConfig(ADC1, ADC_Channel_2, 1, ADC_SampleTime_1Cycles5);
	}

	// Start the measurement and wait
	ADC_StartConversion(ADC1); // Start ADC read
	while (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == 0); // Wait for ADC read

	// Save the value
	x = ADC_GetConversionValue(ADC1); // Read the ADC value

	// return the measured digital value
	return x;
}

float ADC_absolute_voltage(uint16_t ADC_data){
	// This function converts the digital 12-bit value to a voltage, assuming the reference voltage VDDA is 3.3V
	return (float)3.3 / ((1 << 12) - 1) * ADC_data;
}

float ADC_measure_vdda(void) {
	// Measure the internal reference voltage from ADC channel 18

	// Sample time set to 19.5 cycles, which gives a sample time of 2.4375 us
	ADC_RegularChannelConfig(ADC1, ADC_Channel_18, 1, ADC_SampleTime_19Cycles5);

	ADC_StartConversion(ADC1); // Start ADC read
	while (ADC_GetFlagStatus(ADC1, ADC_FLAG_EOC) == 0); // Wait for ADC read

	// Calculate and save the reference voltage
	uint16_t VREFINT_DATA = ADC_GetConversionValue(ADC1);
	float VDDA = 3.3f * ((float)VREFINT_CAL / (float)VREFINT_DATA);

    return VDDA;
}

float ADC_absolute_voltage_calibrated(uint16_t ADC_data, float VDDA){
	// This function converts the digital 12-bit value to a voltage, using the internally measured reference voltage VDDA
	return VDDA / ((1 << 12) - 1) * (float)ADC_data;
}
