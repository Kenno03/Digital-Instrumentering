#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course
#include "timer.h"

void initTimer(void) {

	// Enable TIM2 clock
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);

	// Configure TIM2
	TIM_TimeBaseInitTypeDef TIM_InitStructure;
	TIM_TimeBaseStructInit(&TIM_InitStructure);
	TIM_InitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_InitStructure.TIM_CounterMode = TIM_CounterMode_Up;
	TIM_InitStructure.TIM_Period = 6399; // ARR
	TIM_InitStructure.TIM_Prescaler = 99; // PSC
	TIM_TimeBaseInit(TIM2,&TIM_InitStructure);

	// Enable TIM2 interrupt in NVIC
	NVIC_InitTypeDef NVIC_InitStructure;
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&NVIC_InitStructure);

	// Enable TIM2 update interrupt
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);

	// Start TIM2
	TIM_Cmd(TIM2,ENABLE);
}

volatile time sw = {0,0,0};

void TIM2_IRQHandler(void) {
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) {
		TIM_ClearITPendingBit(TIM2,TIM_IT_Update); // Clear interrupt bit
		sw.hs++;
		if (sw.hs >= 100) {
			sw.hs = 0;
			sw.s++;
		}
		if (sw.s >= 60) {
			sw.s = 0;
			sw.m++;
		}
	}
 }
