#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course

void initSPI3() {
	// Enable clocks
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI3, ENABLE);
	// Clock for pins:
	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_GPIOC,ENABLE); // Enable clock for GPIO Port C


	GPIO_InitTypeDef GPIO_InitStructAll; // Define typedef struct for setting pin
	// Sets PC0 to input
	GPIO_StructInit(&GPIO_InitStructAll); // Initialize GPIO struct

	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_OUT;
	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_DOWN;
	GPIO_InitStructAll.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_9; // CS pin
	GPIO_Init(GPIOC, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	GPIO_InitStructAll.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_NOPULL; // Set as pull down
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_10; // SCLK
	GPIO_Init(GPIOC, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_DOWN; // Set as pull down
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_11; // MISO
	GPIO_Init(GPIOC, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	GPIO_InitStructAll.GPIO_PuPd = GPIO_PuPd_NOPULL; // Set as pull down
	GPIO_InitStructAll.GPIO_Pin = GPIO_Pin_12; // MOSI
	GPIO_Init(GPIOC, &GPIO_InitStructAll); // Setup of GPIO with the settings chosen

	// Configure alternate function
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource10, GPIO_AF_6);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource11, GPIO_AF_6);
	GPIO_PinAFConfig(GPIOC, GPIO_PinSource12, GPIO_AF_6);


	SPI_InitTypeDef SPI_InitStruct;
	SPI_StructInit(&SPI_InitStruct);
	// SPI3 settings
	SPI_InitStruct.SPI_Mode = SPI_Mode_Master;
	SPI_InitStruct.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
	SPI_InitStruct.SPI_DataSize = SPI_DataSize_8b;
	SPI_InitStruct.SPI_NSS = SPI_NSS_Soft;
	SPI_InitStruct.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_8;
	SPI_InitStruct.SPI_CPOL = SPI_CPOL_High;
	SPI_InitStruct.SPI_CPHA = SPI_CPHA_2Edge; // Mode 3


	SPI_Init(SPI3, &SPI_InitStruct);

	GPIO_SetBits(GPIOC, GPIO_Pin_9); // CS high at startup

	SPI_Cmd(SPI3, ENABLE);
}

uint8_t SPI_ReadRegister(uint8_t reg_addr) {
    uint8_t value;

    // Add read bit (MSB = 1)
    reg_addr |= 0x80;


    GPIO_ResetBits(GPIOC, GPIO_Pin_9); // CS low

    // Send register address
    while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_TXE) == RESET);
    SPI_SendData8(SPI3, reg_addr);
    while (SPI_I2S_GetFlagStatus(SPI3, SPI_I2S_FLAG_RXNE) == RESET);
    value = SPI_ReceiveData8(SPI3);

    GPIO_SetBits(GPIOC, GPIO_Pin_9); // CS high

    return value;
}
