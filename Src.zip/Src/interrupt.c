#include "stm32f30x_conf.h" // STM32 config
#include "30010_io.h" // Input/output library for this course

void initInterrupt(){
	// Initialize the interrupt and connect it to EXTI line 4, triggered by pin PA4, and connect it to the NVIC as the highest priority

	// Enable the clock for the System configuration controller to enable configuration of interrupts
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG,ENABLE);

	// Set the port and pin to be connected to the interrupt line
	SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA,EXTI_PinSource4);

	// define and set setting for EXTI
	EXTI_InitTypeDef EXTI_InitStruct;
	EXTI_InitStruct.EXTI_Line = EXTI_Line4; // Select EXTI line 4
	EXTI_InitStruct.EXTI_LineCmd = ENABLE;
	EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
	EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Rising;
	EXTI_Init(&EXTI_InitStruct); // Run the initialization functions with the given settings

	// setup NVIC with the highest priority, 0
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);
	NVIC_InitTypeDef NVIC_InitStruct;
	NVIC_InitStruct.NVIC_IRQChannel = EXTI4_IRQn; // Connect NVIC to EXTI line 4
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 0;
	NVIC_Init(&NVIC_InitStruct); // Run the initialization functions with the given settings

	NVIC_SetPriority(EXTI4_IRQn, 0); // Set interrupt priority as the highest
	NVIC_EnableIRQ(EXTI4_IRQn); // Enable the interrupt
}

void EXTI4_IRQHandler(void){
	// Configure the code that will run when the interrupt on EXTI line 4 is triggered

	if(EXTI_GetITStatus(EXTI_Line4) != RESET){
		// print the state of each joystick pin
		printf("Right : %d  | Up : %d  |  Center : %d  |  Left : %d  |  Down : %d  \n",
				GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_0),
				GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_4),
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_5),
				GPIO_ReadInputDataBit(GPIOC,GPIO_Pin_1),
				GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_0));

		// Set the LED to light up
		GPIO_WriteBit(GPIOC,GPIO_Pin_7,Bit_RESET);

		// Clear the pending bit
		EXTI_ClearITPendingBit(EXTI_Line4);
	}
}
